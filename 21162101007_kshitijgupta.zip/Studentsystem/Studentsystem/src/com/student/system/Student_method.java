package com.student.system;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.cj.protocol.Resultset;

//import com.mysql.cj.xdevapi.Statement;

public class Student_method {
	
	public static boolean  DB(studentclass stu) {
		
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String K = "insert into studentinfo(Addmission_year, Name, School_Name, DOB, Gender, Cast, standard, State, city, pincode,Living_year) values(?,?,?,?,?,?,?,?,?,?,?)";
			//preparedStatement
			PreparedStatement pstmt = con.prepareStatement(K);
			//set the values of parameters
			pstmt.setInt(1, stu.getAddmission_year());
			pstmt.setString(2, stu.getName());
			pstmt.setString(3, stu.getSchool_Name());
			pstmt.setString(4, stu.getDOB());
			pstmt.setString(5, stu.getGender());
			pstmt.setString(6, stu.getCast());
			pstmt.setInt(7, stu.getstandard());
			pstmt.setString(8, stu.getState());
			pstmt.setString(9, stu.getCity());
			pstmt.setInt(10, stu.getPincode());
			pstmt.setInt(11, stu.getLiving_year());

			
			
			// execute part......
			
			pstmt.executeUpdate();
			f = true;
		
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
	}

	public static boolean deletestudent(int SID) {
		// TODO Auto-generated method stub
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String K = "delete from studentinfo where S_id = ?";
			//preparedStatement
			PreparedStatement pstmt = con.prepareStatement(K);
			//set the values of parameters
			pstmt.setInt(1, SID);
	
			// execute part.....
			
		pstmt.executeUpdate();
			
			f = true;
			
			
			// ----------------------------------------------------------------------------------------------
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
	}


	
	public static boolean ShowStudent() {
////		// TODO Auto-generated method stub
	   boolean f =false;
////		//DATABASE CODE BEGIN
////		
	try {
		Connection con = Studentconnection.createC();
		String K = "select * from studentinfo";
		Statement stm = con.createStatement();
//			
			ResultSet set = stm.executeQuery(K);
//			
			while(set.next()) {
//				 
				 int S_id =set.getInt(1);
				 int Addmission_year = set.getInt("Addmission_year");
				 String Name = set.getString("Name");
				 String School_Name = set.getString("School_Name");
				 int DOB =set.getInt("DOB");
				 String Gender = set.getString("Gender");
				 String Cast = set.getString("Cast");
				 int standard =set.getInt("standard");
				 String State = set.getString("State");
				 String city = set.getString("city");
				 int pincode = set.getInt("pincode");
				 int Living_year = set.getInt("Living_year");
				 
				 System.out.println("SID : "+S_id);
				 System.out.println("Addmission_y : "+Addmission_year);
				 System.out.println("Name : "+Name);
				 System.out.println("School_name : "+School_Name);
				 System.out.println("DOB : "+DOB);
				 System.out.println("Gender : "+Gender);
				 System.out.println("Cast : "+Cast);
				 System.out.println("standard : "+standard);
				 System.out.println("State : "+State);
				 System.out.println("City : "+city);
				 System.out.println("Pincode : "+pincode);
				 System.out.println("Living_y : "+Living_year);
				 System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");


				 
			}
			
			
			f = true;
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
}

	
	public static boolean updateStudentRecord(int val,String toUpdate,int id,studentclass stu) {
		// TODO Auto-generated method stub
		boolean f = false;
		
		try {
			Connection con = Studentconnection.createC();
			 if(val == 1) {
					//Update Name
					
						String query = "update studentinfo set Name=? where S_id=?";
						PreparedStatement pstmt = con.prepareStatement(query);
						pstmt.setString(1, toUpdate);
						pstmt.setInt(2, id);
						
						//execute..
						pstmt.executeUpdate();
						f = true;
				}
				else if(val == 2) {
					//Update DOB
					String query = "update studentinfo set DOB=? where S_id=?";
					PreparedStatement pstmt = con.prepareStatement(query);
					pstmt.setString(1, toUpdate);
					pstmt.setInt(2, id);
					
					//execute..
					pstmt.executeUpdate();
					f = true;
				}
			 
				else if(val == 4) {
					//Update state
					String query = "update studentinfo set State=? where S_id=?";
					PreparedStatement pstmt = con.prepareStatement(query);
					pstmt.setString(1, toUpdate);
					pstmt.setInt(2, id);
					
					//execute..
					pstmt.executeUpdate();
					f = true;
				}
				else if(val == 5) {
					//Update city
					String query = "update studentinfo set city=? where S_id=?";
					PreparedStatement pstmt = con.prepareStatement(query);
					pstmt.setString(1, toUpdate);
					pstmt.setInt(2, id);
					
					//execute..
					pstmt.executeUpdate();
					f = true;
				}
				
				else {
					System.out.println("Something went Wroung....");
				}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return f;
	}

	public static boolean updateSstudentRecord(int val, int standard, int id, studentclass stu) {
		// TODO Auto-generated method stub
				boolean f =false;
				//DATABASE CODE BEGIN
				
				try {
					Connection con = Studentconnection.createC();
					String query = "update studentinfo set standard=? where S_id=?";
					PreparedStatement pstmt = con.prepareStatement(query);
					pstmt.setInt(1, standard);
					pstmt.setInt(2, id);
					
					//execute..
					pstmt.executeUpdate();
					f = true;
					
				
				} 
				catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				return f;

	}

	public static boolean updateSptudentRecord(int val, int pincode, int id, studentclass stu) {
		// TODO Auto-generated method stub
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String query = "update studentinfo set pincode=? where S_id=?";
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, pincode);
			pstmt.setInt(2, id);
			
			//execute..
			pstmt.executeUpdate();
			f = true;
			
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;

	}

	public static boolean showcast(int val, String cast, studentclass stu) {
		// TODO Auto-generated method stub
				boolean f =false;
				//DATABASE CODE BEGIN
				
				try {
					Connection con = Studentconnection.createC();
					String query = "select * from studentinfo where cast = ?";
				    PreparedStatement pstmt = con.prepareStatement(query);
				    pstmt.setString(1, cast);
		
				//execute..
				    ResultSet rs = null;
					rs = pstmt.executeQuery();					
              		f = true;			
					
		            System.out.println("DROP-OUT rate cast wise ");
					System.out.println("==================================================================");

		 
		            // Condition check
		            while (rs.next()) {
		 

		                String castt = rs.getString("cast");

		                System.out.println(cast);
		            }
				
				} 
				catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				return f;

	}

	public static boolean show_Sn(int val, String s_name, studentclass stu) {
		// TODO Auto-generated method stub
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String query = "select * from studentinfo where School_Name = ?";
		    PreparedStatement pstmt = con.prepareStatement(query);
		    pstmt.setString(1, s_name);

		//execute..
		    ResultSet rs = null;
			rs = pstmt.executeQuery();					
      		f = true;			
			
            System.out.println("DROP-OUT rate cast wise ");
			System.out.println("==================================================================");

 
            // Condition check
            while (rs.next()) {
 

                String School_Name = rs.getString("School_Name");

                System.out.println(s_name);
            }
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;

	}

	public static boolean gender(int val, String s_Gender, studentclass stu) {
		// TODO Auto-generated method stub
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String query = "select * from studentinfo where Gender = ?";
		    PreparedStatement pstmt = con.prepareStatement(query);
		    pstmt.setString(1, s_Gender);

		//execute..
		    ResultSet rs = null;
			rs = pstmt.executeQuery();					
      		f = true;			
			
            System.out.println("DROP-OUT rate Gender wise ");
			System.out.println("==================================================================");

 
            // Condition check
            while (rs.next()) {
 

                String Gender = rs.getString("Gender");

                System.out.println(s_Gender);
            }
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
	}

	public static boolean classs(int val, String s_class, studentclass stu) {
		// TODO Auto-generated method stub
				boolean f =false;
				//DATABASE CODE BEGIN
				
				try {
					Connection con = Studentconnection.createC();
					String query = "select * from studentinfo where Standard = ?";
				    PreparedStatement pstmt = con.prepareStatement(query);
				    pstmt.setString(1, s_class);

				//execute..
				    ResultSet rs = null;
					rs = pstmt.executeQuery();					
		      		f = true;			
					
		            System.out.println("DROP-OUT rate Standard wise ");
					System.out.println("==================================================================");

		 
		            // Condition check
		            while (rs.next()) {
		 

		                String Standard = rs.getString("Standard");

		                System.out.println(s_class);
		            }
				
				} 
				catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				return f;
	}

	public static boolean state(int val, String s_state, studentclass stu) {
		// TODO Auto-generated method stub
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String query = "select * from studentinfo where State = ?";
		    PreparedStatement pstmt = con.prepareStatement(query);
		    pstmt.setString(1, s_state);

		//execute..
		    ResultSet rs = null;
			rs = pstmt.executeQuery();					
      		f = true;			
			
            System.out.println("DROP-OUT rate State wise ");
			System.out.println("==================================================================");

 
            // Condition check
            while (rs.next()) {
 

                String State = rs.getString("State");

                System.out.println(s_state);
            }
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
	}

	public static boolean City(int val, String s_City, studentclass stu) {
		// TODO Auto-generated method stub
		boolean f =false;
		//DATABASE CODE BEGIN
		
		try {
			Connection con = Studentconnection.createC();
			String query = "select * from studentinfo where city = ?";
		    PreparedStatement pstmt = con.prepareStatement(query);
		    pstmt.setString(1, s_City);

		//execute..
		    ResultSet rs = null;
			rs = pstmt.executeQuery();					
      		f = true;			
			
            System.out.println("DROP-OUT rate City wise ");
			System.out.println("==================================================================");

 
            // Condition check
            while (rs.next()) {
 

                String S_City = rs.getString("city");

                System.out.println(s_City);
            }
		
		} 
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
	}

	
}















