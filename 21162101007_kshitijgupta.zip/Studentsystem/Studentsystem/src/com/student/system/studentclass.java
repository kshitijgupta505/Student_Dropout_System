package com.student.system;

public class studentclass {
		
	
	private int	S_id;       
	private int	 Addmission_year; 
	private String	 Name;            
	private String	 School_Name;    
	private String	 DOB;            
	private String	 Gender;          
	private String	 Cast;          
	private int	 standard;           
	private String	 State;           
	private String	 city;           
	private int	 pincode;         
	private int	 living_year;
	public studentclass(int s_id, int addmission_year, String name, String school_Name, String dOB, String gender,
			String cast, int standard1, String state, String city, int pincode, int living_year) {
		super();
		S_id = s_id;
		Addmission_year = addmission_year;
		Name = name;
		School_Name = school_Name;
		DOB = dOB;
		Gender = gender;
		Cast = cast;
		standard = standard1;
		State = state;
		this.city = city;
		this.pincode = pincode;
		this.living_year = living_year;
	}
	public studentclass(int addmission_year, String name, String school_Name, String dOB, String gender, String cast,
			int standard1, String state, String city, int pincode, int living_year) {
		super();
		Addmission_year = addmission_year;
		Name = name;
		School_Name = school_Name;
		DOB = dOB;
		Gender = gender;
		Cast = cast;
		standard = standard1;
		State = state;
		this.city = city;
		this.pincode = pincode;
		this.living_year = living_year;
	}
	public studentclass() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getS_id() {
		return S_id;
	}
	public void setS_id(int s_id) {
		S_id = s_id;
	}
	public int getAddmission_year() {
		return Addmission_year;
	}
	public void setAddmission_year(int addmission_year) {
		Addmission_year = addmission_year;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSchool_Name() {
		return School_Name;
	}
	public void setSchool_Name(String school_Name) {
		School_Name = school_Name;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getCast() {
		return Cast;
	}
	////////
	public int getClass(int standard) {
		return standard;
	}
	/////
	public void setCast(String cast) {
		Cast = cast;
	}
	public int getstandard() {
		return standard;
	}
	public void setstandard(int standard1) {
		standard = standard1;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getLiving_year() {
		return living_year;
	}
	public void setLiving_year(int living_year) {
		this.living_year = living_year;
	}

	@Override
	public String toString() {
		return "student_info [S_id=" + S_id + ", Addmission_year=" + Addmission_year + ", Name=" + Name + ", School_Name="
				+ School_Name + ", DOB=" + DOB + ", Gender=" + Gender + ", Cast=" + Cast + ", standard=" + standard + ", State="
				+ State + ", city=" + city + ", pincode=" + pincode + ", living_year=" + living_year + "]";
	}


}







