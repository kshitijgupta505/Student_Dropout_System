package com.student.system;

import java.sql.Connection;
import java.sql.DriverManager;

public class Studentconnection {
	
	static	Connection con;
	// connection create
	
	
		public static Connection createC() {
			try {
			  // load the driver
				Class.forName("com.mysql.cj.jdbc.Driver");
				//Class.forName("com.mysql.jdbc.Driver");
				
				//create the connection begin 
				String user ="root";
				String password = "Kshitij@8866";
				String url = "jdbc:mysql://localhost:3306/studentds?autoReconnect=true&useSSL=false";
				//String url = "jdbc:mysql://localhost:3306/studentds";
				con = DriverManager.getConnection(url, user, password);
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return con;
		}
}

