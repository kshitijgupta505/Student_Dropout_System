import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.student.system.Student_method;
import com.student.system.studentclass;
import java.util.Scanner;
     

public class hello {

	public static void main(String[] args)throws IOException  {
		
		String Username;
	    String Password;

	    Password = "moj_mai";
	    Username = "kai_se_ho";

	    Scanner input1 = new Scanner(System.in);
	    System.out.println("Enter Username : ");
	    String username = input1.next();

	    Scanner input2 = new Scanner(System.in);
	    System.out.println("Enter Password : ");
	    String password = input2.next();

	    if (username.equals(Username) && password.equals(Password)) {

	    	
	    	System.out.println("Namste! KYA IRADA HAI AAPKA");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
	    	
	    	
	    	
			
		    while(true) {
			System.out.println("1. ADD DROUP-OUT STUDENT DETAILS");
			System.out.println("2. DELETE STUDENT ");
			System.out.println("3. SHOW STUDENT DETAILS");
			System.out.println("4. UPDATE student DETAILS");
			System.out.println("5. check Droup-out rate");
			System.out.println(" ...Press 6 to exit...");
			int c = Integer.parseInt(br.readLine());
			
			if(c==1) {
				//ADD STUDENT DETAILS
				System.out.println("Enter Addmission_year ");
				int student_year = Integer.parseInt(br.readLine());
				
				System.out.println("Enter Name");
				String S_name = br.readLine();
				
				System.out.println("Enter School_Name");
				String S_sn = br.readLine();
				
				System.out.println("Enter DOB");
				String S_DOB= br.readLine();
				
				System.out.println("Enter Gender");
				String S_gender = br.readLine();
				
				System.out.println("Enter Cast");
				String S_cast = br.readLine();
				
				System.out.println("Enter Class");
				int S_standard = Integer.parseInt(br.readLine());
				
				System.out.println("Enter State");
				String S_state = br.readLine();
				
				System.out.println("Enter city");
				String S_city = br.readLine();
				
				System.out.println("Enter pincode");
				int S_pcode = Integer.parseInt(br.readLine());
				
				System.out.println("Enter living_year");
				int S_livingY = Integer.parseInt(br.readLine());
				
				// student object to store the student
				studentclass stu = new studentclass(student_year ,S_name,S_sn,S_DOB,S_gender,S_cast,S_standard,S_state, S_city,S_pcode,S_livingY);
				System.out.println(stu);
				//JDBC
				boolean answer = Student_method.DB(stu);
				if(answer) {
					System.out.println("done");
				}
				else {
					System.out.println("wroung");
				}
				
			}
			if(c==2){
				// DELETE STUDENT
				System.out.println(" Enter the S_id to delete the student");
				int SID = Integer.parseInt(br.readLine());
				boolean chek = Student_method.deletestudent(SID);
				if(chek) {
					System.out.println("Student deleted.......");
				}
				else {
					System.out.println("Something went Wroung..");
				}
					
			}
			else if(c==3) {
				// SHOW STUDENT DETAILS
				System.out.println("Press 3 to show table");
				boolean chek = Student_method.ShowStudent();
				if(chek) {
					System.out.println("Student deleted.......");
				}
				else {
					System.out.println("Something went Wroung..");
				}
//				
		}
			else if(c==4) {
				
				//Update student
				System.out.println("PRESS 1 to UPDATE name");
				System.out.println("PRESS 2 to UPDATE DOB");				
				System.out.println("PRESS 3 to UPDATE standard");
				System.out.println("PRESS 4 to UPDATE state");
				System.out.println("PRESS 5 to UPDATE city");
				System.out.println("PRESS 6 to UPDATE pincode");
				System.out.println("PRESS any key TO exit");
				int val = Integer.parseInt(br.readLine());
				if(val == 1) {
					//Update Name
					System.out.println("Enter name to UPDATE...");
					String Name = br.readLine();
					System.out.println("Enter ID to identify student!");
					int S_id = Integer.parseInt(br.readLine());
					studentclass stu = new studentclass();
					stu.setName(Name);
					boolean f = Student_method.updateStudentRecord(val ,Name,S_id,stu);
					if(f) {
						System.out.println("Student Name Updated Successfully...");
					}else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				else if(val == 2) {
					//Update DOB
					System.out.println("Enter DOB to UPDATE...");
					String S_DOB = br.readLine();
					System.out.println("Enter ID to identify student!");
					int id = Integer.parseInt(br.readLine());
					studentclass stu = new studentclass();
					stu.setDOB(S_DOB);
					boolean f = Student_method.updateStudentRecord(val,S_DOB,id,stu);
					if(f) {
						System.out.println("Student DOB Updated Successfully...");
					}else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				else if(val == 3) {
					//Update standard
					System.out.println("Enter standard to UPDATE...");
					int standard = Integer.parseInt(br.readLine());
					System.out.println("Enter ID to identify student!");
					int id = Integer.parseInt(br.readLine());
					studentclass stu = new studentclass();
					stu.setstandard(standard);
					boolean f = Student_method.updateSstudentRecord(val,standard,id,stu);
					if(f) {
						System.out.println("Student standard Updated Successfully...");
					}else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				else if(val == 4) {
					//Update STATE
					System.out.println("Enter state to UPDATE...");
					String S_state = br.readLine();
					System.out.println("Enter ID to identify student!");
					int id = Integer.parseInt(br.readLine());
					studentclass stu = new studentclass();
					stu.setState(S_state);
					boolean f = Student_method.updateStudentRecord(val,S_state,id,stu);
					if(f) {
						System.out.println("Student state Updated Successfully...");
					}else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				else if(val == 5) {
					//Update city
					System.out.println("Enter city to UPDATE...");
					String S_city = br.readLine();
					System.out.println("Enter ID to identify student!");
					int id = Integer.parseInt(br.readLine());
					studentclass stu = new studentclass();
					stu.setState(S_city);
					boolean f = Student_method.updateStudentRecord(val,S_city,id,stu);
					if(f) {
						System.out.println("Student state Updated Successfully...");
					}else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				else if(val == 6) {
					//Update Pincode
					System.out.println("Enter pincode to UPDATE...");
					int pincode = Integer.parseInt(br.readLine());
					System.out.println("Enter ID to identify student!");
					int id = Integer.parseInt(br.readLine());
					studentclass stu = new studentclass();
					stu.setstandard(pincode);
					boolean f = Student_method.updateSptudentRecord(val,pincode,id,stu);
					if(f) {
						System.out.println("Student pincode Updated Successfully...");
					}else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				else {
					System.out.println("Hey You have not updated Anything... Please choose option Correctly!");
				}
				
			}
			else if(c == 5) {
				
				System.out.println("1. check DROUP-OUT cast wise");
				System.out.println("2. check DROUP-OUT school wise");
				System.out.println("3. check DROUP-OUT Gender wise");
				System.out.println("4. check DROUP-OUT standard wise");
				System.out.println("5. check DROUP-OUT State wise");
				System.out.println("6. check DROUP-OUT city wise");

				int val = Integer.parseInt(br.readLine());
				if(val == 1) {
					//cast wise DROP-OUT
					System.out.println("Enter cast ");
					String cast = br.readLine();
					studentclass stu = new studentclass();
					stu.setName(cast);
					boolean f = Student_method.showcast(val ,cast,stu);
					if(f) {
						System.out.println("==================================================================");
					}
					else {
						System.out.println("Something Went Wrong Please try Again!");
					}
					
				}
				else if (val==2) {
					//School wise DROP-OUT
					System.out.println("Enter School Name ");
					String S_name = br.readLine();
					studentclass stu = new studentclass();
					stu.setName(S_name);
					boolean f = Student_method.show_Sn(val ,S_name,stu);
					if(f) {
						System.out.println("==================================================================");
					}
					else {
						System.out.println("Something Went Wrong Please try Again!");
					}
					
				}
				
				else if (val == 3) {
					//Gender wise DROP-OUT
					System.out.println("Enter Gender ");
					String S_Gender = br.readLine();
					studentclass stu = new studentclass();
					stu.setName(S_Gender);
					boolean f = Student_method.gender(val ,S_Gender,stu);
					if(f) {
						System.out.println("==================================================================");
					}
					else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				
				else if (val == 4) {
					//Standard wise DROP-OUT
					System.out.println("Enter class ");
					String S_class = br.readLine();
					studentclass stu = new studentclass();
					stu.setName(S_class);
					boolean f = Student_method.classs(val ,S_class,stu);
					if(f) {
						System.out.println("==================================================================");
					}
					else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				
				else if (val == 5) {
					//State wise DROP-OUT
					System.out.println("Enter State ");
					String S_state = br.readLine();
					studentclass stu = new studentclass();
					stu.setName(S_state);
					boolean f = Student_method.state(val ,S_state,stu);
					if(f) {
						System.out.println("==================================================================");
					}
					else {
						System.out.println("Something Went Wrong Please try Again!");
					}
				}
				
				else if (val == 6) {
					//City wise DROP-OUT
					System.out.println("Enter City ");
					String S_City = br.readLine();
					studentclass stu = new studentclass();
					stu.setName(S_City);
					boolean f = Student_method.City(val ,S_City,stu);
					if(f) {
						System.out.println("==================================================================");
					}
					else {
						System.out.println("Something Went Wrong Please try Again!");
					}
}

					else {
					System.out.println("Hey You have not updated Anything... Please choose option Correctly!");
				}
				
			
			}
			
			else if(c == 6) {
				System.out.println("Duya o mai yad karna.......");
				break;
			}
			else {
				//BYE...............
				break;
			}
			}
	    	
		    
	    	
	    }

	    else if (username.equals(Username)) {
	        System.out.println("Invalid Password!");
	    } else if (password.equals(Password)) {
	        System.out.println("Invalid Username!");
	    } else {
	        System.out.println("Invalid Username & Password!");
	    }

		
			}

}


